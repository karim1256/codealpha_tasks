List<Map> dishes = [
  {
    "image": "assets/images/image012.jpg",
    "title": "Dish 01",
    "time": "25 min",
    "calories": "426 kCal",
    "category": "breakfast"
  },
  {
    "image": "assets/images/image013.jpg",
    "title": "Dish 02",
    "time": "10 min",
    "calories": "200 kCal",
    "category": "lunch"
  },
  {
    "image": "assets/images/image014.jpeg",
    "title": "Dish 03",
    "time": "40 min",
    "calories": "634 kCal",
    "category": "dinner"
  },
  {
    "image": "assets/images/image015.jpg",
    "title": "Dish 04",
    "time": "60 min",
    "calories": "1.238 kCal",
    "category": "breakfast"
  },
];